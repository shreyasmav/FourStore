<!DOCTYPE html>  
 <html>  
    <head>  
        <title>Order Confirmation</title>
        <style>
            div{
                text-align:center;
            }
            #img{
                margin-top:10%;
                width:250px;
            }
            .button{
                font-size: 25px;
                color: white;
                background-color: grey;
                border-radius: 15px;
                text-align: center;
                padding: 14px 16px;
                text-decoration: none;
                margin:none;
            }
        </style>
    </head>  
    <body>
        <div ><img id='img' src='Images\check.png'/></div>
        <br>
        <h2 align='center'>Order Confirmed</h2><br><br><br>
        <div><a class='button' href='home.php'>Continue</a></div>
    </body>
</html>