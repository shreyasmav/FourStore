<!DOCTYPE html>  
 <html>  
    <head>  
        <title>Payment Page</title>
        <style>
            .button{
                position: absolute;
                left: 48%;
                font-size: 16px;
                color: white;
                background-color: green;
                border-radius: 15px;
                text-align: center;
                padding: 14px 16px;
                text-decoration: none;
                margin:auto;
}
            }
        </style>  
    </head>  
    <body>
        <br><br><br>
        <h2 align='center'>Payment Portal</h2><br><br>
        
        <a class='button' href='confirmation.php'>Pay Now</a>
    </body>
</html>
        