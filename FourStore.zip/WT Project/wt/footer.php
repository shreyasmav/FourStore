<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="footer.css">
</head>
<body>
<footer class="footsy">
    <div class="row">
      <div class="col-3">
        <h1>Get to Know Us</h1>
        <ul>
          <li>About Us</li>
          <li>Career</li>
          <li>Gift a smile</li>
        </ul>
      </div>
      <div class="col-3">
        <h1>Connect with Us</h1>
        <ul>
          <li>Facebook</li>
          <li>Twitter</li>
          <li>Instagram</li>
        </ul>
      </div>
      <div class="col-3">
        <h1>Make Money</h1>
        <ul>
          <li>Sell on Fourstore</li>
          <li>Become an Affiliate</li>
          <li>Fulfilment by FourStore</li>
        </ul>
      </div>
      <div class="col-3">
        <h1>Let Us Help You</h1>
        <ul>
          <li>Returns Centre</li>
          <li>Purchase Protection</li>
          <li>Help</li>
        </ul>
      </div>
    </div>
  </footer>
</body>
</html>