 <?php
include('header.php');
 ?>
<!DOCTYPE html>
<html>
<head>
  <title>About Us</title>
  <style>
    h2{
      color: darkblue;
      font-size: 40px;
      text-align: center;
    }
    body{
	    background: lightblue url("Images/homepage/home2.jpg") no-repeat fixed center; 
    }
    p{
      font-size: 25px;
    }
    
  </style>
</head>
<body>
  <h2 >About Us</h2>
  <p >This is an ecommerce website created as part of the project for the Web Tech course of 2018-19 by Madhav Agal, Saransh Gupta, Anish Shekhar and Shreyas Mavanoor.We have tried to implement the basic functionality of an ecommerce website which includes an interactive front-end and a back-end database to support different features of the website.The front-end uses different CSS styling features to make the website more appealing and also integrates javascript to propagate this.The backend uses MYSql database to store appropriate information that the webpage requires, this data is accessed with the help of PHP scripts which excecutes them on the server side and thus integrating all the HTML functionality with that of CSS and JS to produce a website capable of implementing some of the features of an ecommerce website on a smaller scale.</p>

</body>
  <?php
include('footer.php');
 ?>
</html>